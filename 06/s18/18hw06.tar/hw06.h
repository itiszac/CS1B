#include <iostream>

int Sum(int *A[], int r);