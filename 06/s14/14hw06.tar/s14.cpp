#include "hw06.h"

int main()
{
  int d[5] = {1, 2, 3, 4, 5};
  int s;
  // i n i t i a l i z e d [ ]
  s = Sum(d);
  std::cout << "s: " << s;
  return 0;
}