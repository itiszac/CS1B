#include "hw06.h"

int main()
{
  int d[5] = {1, 2, 3, 4, 5};
  int s;
  // i n i t i a l i z e d [ ]
  s = Sum(d, 5);
  std::cout << "s: " << s << std::endl;
  return 0;
}