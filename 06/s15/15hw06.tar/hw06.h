#include <iostream>

int Sum(int *p, int k);