#include <iostream>

int Sum(int **p, int r, int c);