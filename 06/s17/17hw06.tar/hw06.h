#include <iostream>

int Sum(int A[][8]);