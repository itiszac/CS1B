#pragma once
/*************************************************************
 * Zachary Meyer * CS1B TTH 07:30 - 09:50 PM * Assignment 9  *
 * Operator Overload * Due: Tuesday, November 24, 2020       *
 *************************************************************/
/*************************************************************
 * Program: BigInt Arithematic                               *
 * Desc: Take user input of 2 large integers and store them  *
 * in 2 LinkedLists, output the sum, difference, and product.*
 *************************************************************/
#include <iostream>
#include <string>
