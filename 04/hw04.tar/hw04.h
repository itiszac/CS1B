#pragma once
/*************************************************************
 * Zachary Meyer * CS1B TTH 07:30 - 09:50 PM * Assignment 4  *
 * CMake * Due: Thursday, September 24, 2020                 *
 *************************************************************/
#include <iostream>
/*************************************************************
 * Program: Income Tax Calculation
 * Desc: Prompt user for data like income, expense,
 * deductions, etc. and calculate the income tax
 * for a given year.
 *************************************************************/
