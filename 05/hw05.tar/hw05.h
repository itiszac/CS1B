#pragma once
/*************************************************************
 * Zachary Meyer * CS1B TTH 07:30 - 09:50 PM * Assignment 5  *
 * structs * Due: Tuesday, October 13, 2020                  *
 *************************************************************/
/*************************************************************
 * Program: Football Statistic Database                      *
 * Desc: Read and write from a txt file and store in         *
 * a array of structs, give the user an option to output,    *
 * input, update the various players and stats.              *
 *************************************************************/