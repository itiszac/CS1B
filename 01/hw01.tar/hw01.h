/*************************************************************
 *  Zachary Meyer * CS1B TTH 07:30 - 09:50 PM * Assignment 1 *
 *  Newton's Law  * Due: Thursday, September 3, 2020         *
 *************************************************************/
#include <iostream>
#include <cmath>
#include <string>
/*************************************************************
 * Program: Netwon's Law Calculator
 * Desc: Takes a users input, calculates the force
 * using Newton's Law of Gravity and outputs results.
 *************************************************************/

float GetFloat(std::string output);
